package com.cg.fms.model;

public class CourseMasterBean {
	private String courseId;
	private String courseName;
	private String noOfDays;

	public CourseMasterBean(String courseId, String courseName, String noOfDays) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}

	public CourseMasterBean(String courseId) {
		super();
		this.courseId = courseId;
	}

	@Override
	public String toString() {
		return "CourseMasterBean [courseId=" + courseId + ", courseName="
				+ courseName + ", noOfDays=" + noOfDays + "]";
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}

	public CourseMasterBean() {
	}
}
