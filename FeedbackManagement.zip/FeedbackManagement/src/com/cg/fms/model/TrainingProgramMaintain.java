package com.cg.fms.model;

public class TrainingProgramMaintain {
private String trainingCode;
private String ParticipantId;
private String courseId;
private String courseName;
private String noDays;
private String facultId;
private String skillSet;
private String startDate;
private String endDate;
public TrainingProgramMaintain(String trainingCode, String participantId,
		String courseId, String courseName, String noDays, String facultId,
		String skillSet, String startDate, String endDate) {
	super();
	this.trainingCode = trainingCode;
	ParticipantId = participantId;
	this.courseId = courseId;
	this.courseName = courseName;
	this.noDays = noDays;
	this.facultId = facultId;
	this.skillSet = skillSet;
	this.startDate = startDate;
	this.endDate = endDate;
}
public String getTrainingCode() {
	return trainingCode;
}
public void setTrainingCode(String trainingCode) {
	this.trainingCode = trainingCode;
}
public String getParticipantId() {
	return ParticipantId;
}
public void setParticipantId(String participantId) {
	ParticipantId = participantId;
}
public String getCourseId() {
	return courseId;
}
public void setCourseId(String courseId) {
	this.courseId = courseId;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public String getNoDays() {
	return noDays;
}
public void setNoDays(String noDays) {
	this.noDays = noDays;
}
public String getFacultId() {
	return facultId;
}
public void setFacultId(String facultId) {
	this.facultId = facultId;
}
public String getSkillSet() {
	return skillSet;
}
public void setSkillSet(String skillSet) {
	this.skillSet = skillSet;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}




	
	
}
