package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.CourseFacultyMapBean;
import com.cg.fms.model.CourseMasterBean;
import com.cg.fms.model.FacultySkillMasterBean;
import com.cg.fms.model.LoginBean;
import com.cg.fms.model.TrainingProgramMaintain;
import com.cg.fms.model.feedbackBean;

public interface IFeedbackDao {

	String checkRole(LoginBean login) throws FMSException;

	int insertFacultySkill(FacultySkillMasterBean facultySkill) throws FMSException;

	int updateFacultySkillOper(FacultySkillMasterBean facultyupdateSkill) throws FMSException;

	int deletefacultySkilloper(String facultyId) throws FMSException;

	List<FacultySkillMasterBean> viewAllFacultyDetails() throws FMSException;

	List<CourseFacultyMapBean> viewMapDetails() throws FMSException;

	int insertCourseDetails(CourseMasterBean courseBean) throws FMSException;

	int updateCourseOper(CourseMasterBean courseBean1) throws FMSException;

	int deleteCourseoper(String courseId) throws FMSException;

	List<CourseMasterBean> viewAllCourseDetails() throws FMSException;

	List<TrainingProgramMaintain> fetchingTrainingProgramDetails() throws FMSException;

	boolean getTrainingCode(String trainingCode) throws FMSException;

	boolean checkParticipantId(String participantId ,String trainingCode) throws FMSException;

	int insertFeedback(feedbackBean fbBean) throws FMSException;

	String getParticipantId(LoginBean login) throws FMSException;

	

	

	

}
