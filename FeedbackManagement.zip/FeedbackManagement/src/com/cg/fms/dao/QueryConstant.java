package com.cg.fms.dao;

public interface QueryConstant {

	
    public static final String selectrole="select role from employee_master where employee_name=? and password=?";
    public static final String insertQuery ="insert into facultyskill_master values (?,?)";
    public static final String updateQuery="update facultyskill_master set SKILLSET=? where FACULTY_ID=?";
    public static final String deleteQuery="delete from facultyskill_master where FACULTY_ID=? ";
    public static final String viewQuery="select * from facultyskill_master ";
    public static final String mapviewQuery="select c.course_id,c.course_name,c.no_days,f.faculty_id,f.skillset "
    		+ "from course_master c,facultyskill_master f where  c.course_name in f.skillset";
	public static final String insertCourseQuery = "insert into course_master values(?,?,?)";
	public static final String updateCourseQuery = "update course_master set COURSE_NAME=? , NO_DAYS=? where COURSE_ID=?";
	public static final String deleteCourseQuery = "delete from course_master where COURSE_ID=?";
	public static final String viewCourseQuery = "select * from course_master";
	public static final String viewTrainingProgramqry="select tp.training_code,tpm.participant_id,c.course_id,c.course_name,c.no_days,"
			+ "f.faculty_id,f.skillset,tp.start_date,tp.end_date"
			+ " from course_master c,facultyskill_master f,training_participant_master tpm ,"
			+ "training_program_master tp where  c.course_name in f.skillset "
			+ "and tp.training_code=tpm.training_code";
public static final String insFeedbackQuery="insert into  feedback_master values(?,?,?,?,?,?,?,?,?)";
public static final String checkTraineeCodeqry="select training_code from training_program_master ";
public static final String checkParticipantIdqry="SELECT participant_id FROM training_participant_master where training_code=?";
public static final String getParticipantIdfqry="select participant_id from employee_master where employee_name=? and password=?";
}
